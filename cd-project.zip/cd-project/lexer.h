#ifndef LEXER_H
#define LEXER_H

#include <iostream>
#include <vector>
#include <string>

struct Token {
    std::string type;
    std::string value;
};

class Lexer {
public:
    std::vector<Token> tokenize(double a, int b) {
        std::vector<Token> tokens;
        tokens.push_back({"FLOAT", std::to_string(a)});
        tokens.push_back({"OPERATOR", "*"});
        tokens.push_back({"INT", "10"});
        tokens.push_back({"OPERATOR", "^"});
        tokens.push_back({"INT", std::to_string(b)});

        std::cout << "Tokens:\n";
        for (const auto& token : tokens) {
            std::cout << "<" << token.type << ", " << token.value << ">\n";
        }
        std::cout << std::endl;

        return tokens;
    }
};

#endif
#ifndef COMPILER_H
#define COMPILER_H

#include <iostream>
#include <iomanip>
#include <cmath>
#include "lexer.h"
#include "parser.h"
#include "optimizer.h"
#include "codegen.h"

class Compiler {
public:
    void compile(double a, int b) {
        Lexer lexer;
        auto tokens = lexer.tokenize(a, b);

        Parser parser;
        auto tac = parser.parse(tokens);

        Optimizer optimizer;
        optimizer.optimize(tac);

        CodeGenerator codegen;
        codegen.generate(tac);

        double intensity = a * pow(10, b);
        double decibels = 10 * log10(intensity / 1e-12);
        std::cout << std::fixed << std::setprecision(2);
        std::cout << "Final Output: " << decibels << " dB" << std::endl;
    }
};

#endif
#include <iostream>
#include "compiler.h"

int main() {
    double a;
    int b;

    std::cout << "Enter a (mantissa): ";
    std::cin >> a;
    std::cout << "Enter b (exponent): ";
    std::cin >> b;

    Compiler compiler;
    compiler.compile(a, b);

    return 0;
}
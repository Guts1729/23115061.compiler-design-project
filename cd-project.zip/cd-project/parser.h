#ifndef PARSER_H
#define PARSER_H

#include "lexer.h"
#include <vector>
#include <string>
#include <iostream>

struct TAC {
    std::vector<std::string> code;
};

class Parser {
public:
    TAC parse(const std::vector<Token>& tokens) {
        double a = std::stod(tokens[0].value);
        int b = std::stoi(tokens[4].value);

        TAC tac;
        tac.code.push_back("t1 = 10 ^ " + std::to_string(b));
        tac.code.push_back("t2 = " + std::to_string(a) + " * t1");
        tac.code.push_back("t3 = t2 / 1e-12");
        tac.code.push_back("t4 = log10(t3)");
        tac.code.push_back("dB = 10 * t4");

        std::cout << "Three Address Code (TAC):\n";
        for (const auto& line : tac.code) {
            std::cout << line << std::endl;
        }
        std::cout << std::endl;

        return tac;
    }
};

#endif
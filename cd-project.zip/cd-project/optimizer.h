#ifndef OPTIMIZER_H
#define OPTIMIZER_H

#include "parser.h"
#include <iostream>

class Optimizer {
public:
    void optimize(const TAC& tac) {
        std::cout << "Optimized Instruction:\n";
        std::cout << tac.code.back() << std::endl << std::endl;
    }
};

#endif
# 23115061.compiler-design-project
Design a custom instruction for a given equation in compiler.
# Sound Intensity to Decibel Compiler

This project is a simulated compiler for converting sound intensity to decibels using structured phases, implemented in C++.

## Equation

Decibels (dB) = 10 * log10(I / I0), where I0 = 10^-12

## Input Format

Enter intensity as:
1. `a` (mantissa) - a float or double value
2. `b` (exponent) - an integer

Example: for I = 2.5 × 10^(-5), input `a = 2.5`, `b = -5`.

## Compilation Phases

1. **Lexical Analysis** - Converts raw input to tokens.
2. **Parsing** - Converts tokens to abstract representation.
3. **Intermediate Code Generation (TAC)**.
4. **Optimization** - Generates simplified instructions.
5. **Assembly Code Generation**.
6. **Execution** - Prints the final decibel value.

## installation msys2 mingw64
Go to the official MSYS2 website:
link: https://www.msys2.org/
Click on “Installer for 64-bit” to download the installer (e.g., msys2-x86_64-*.exe).

download and Install msys2
-Open the MSYS2 shell from Start Menu: Look for "MSYS2 MSYS" 
### Run the update command:
command: pacman -Syu

###  Install MinGW 64-bit Toolchain

Open MSYS2 MinGW 64-bit shell:

Start Menu → MSYS2 → MSYS2 MinGW 64-bit

Install the GCC C/C++ compiler and make:


pacman -S mingw-w64-x86_64-gcc make


### Confirm its working

In the MSYS2 MinGW 64-bit shell, run:

g++ --version
make --version

If you see version info, you're good to go!

## Running main file
1. open msys2 mingw64 terminal shell

2. go to path of cd-project file (using cd command ex: cd /c/Users/Adminname/cd-project)

3. run command: make 

4. you get output as: g++ main.cpp -o compiler

5. then run command ./compiler.exe

6. it asks inputs a and b one-by-one

7. give inputs

8. it gives output
## EXAMPLE OUTPUT 

Enter a (mantissa): 2.3
Enter b (exponent): 5
Tokens:
<FLOAT, 2.300000>
<OPERATOR, *>
<INT, 10>
<OPERATOR, ^>
<INT, 5>

Three Address Code (TAC):
t1 = 10 ^ 5
t2 = 2.300000 * t1
t3 = t2 / 1e-12
t4 = log10(t3)
dB = 10 * t4

Optimized Instruction:
dB = 10 * t4

Assembly Code:
MOV R1, 10
MOV R2, EXPONENT
POW R3, R1, R2
MOV R4, MANTISSA
MUL R5, R3, R4
MOV R6, 1e-12
DIV R7, R5, R6
LOG10 R8, R7
MUL R9, R8, 10
OUTPUT R9

Final Output: 173.62 dB
### Using VSCode

1. install vscode and install c/c++ extensions

2. extract project file and open in vscode

3. run main.cpp file and give inputs
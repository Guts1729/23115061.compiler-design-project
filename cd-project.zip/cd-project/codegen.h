#ifndef CODEGEN_H
#define CODEGEN_H

#include "parser.h"
#include <iostream>

class CodeGenerator {
public:
    void generate(const TAC& tac) {
        std::cout << "Assembly Code:\n";
        std::cout << "MOV R1, 10\n";
        std::cout << "MOV R2, EXPONENT\n";
        std::cout << "POW R3, R1, R2\n";
        std::cout << "MOV R4, MANTISSA\n";
        std::cout << "MUL R5, R3, R4\n";
        std::cout << "MOV R6, 1e-12\n";
        std::cout << "DIV R7, R5, R6\n";
        std::cout << "LOG10 R8, R7\n";
        std::cout << "MUL R9, R8, 10\n";
        std::cout << "OUTPUT R9\n\n";
    }
};

#endif